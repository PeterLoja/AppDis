package ec.ups.edu.proyecto.jpa.bussiness;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;


import ec.ups.edu.proyecto.jpa.dao.AdministradorDAO;
import ec.ups.edu.proyecto.jpa.dao.EstudianteDAO;
import ec.ups.edu.proyecto.jpa.model.Administrador;
/**
 * 
 * 
 * Clase que permite aplicar las reglas de negocio
 * y la manipulacion de los datos
 *
 * @author Pedro
 *
 */
@Stateless
public class AdministradorBussiness {

	@Inject
	private AdministradorDAO adao;
	/**
	 * Metodo que manipula los datos recibidos de la 
	 * interfaz login.xhtml
	 * @param usuario
	 * @param pass
	 * @return
	 */
	public Administrador Iniciar(String usuario, String pass){
		return adao.admi(usuario, pass);
	}
	
	
	
	
}
