package ec.ups.edu.proyecto.jpa.bussiness;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import ec.ups.edu.proyecto.jpa.dao.CursoDAO;
import ec.ups.edu.proyecto.jpa.model.Curso;
/**
 * 
 * Clase que permite aplicar las reglas de negocio
 * y la manipulacion de los datos
 * 
 */
@Stateless
public class CursoBussiness {
	
	@Inject
	private CursoDAO cdao;
	/**
	 * Metodo que permite almacenar un curso
	 * @param curso
	 * @throws Exception
	 */
	public void save(Curso curso) throws Exception{
		Curso aux=cdao.read(curso.getId());
		if(aux!=null)
			throw new Exception("Curso ya registrado");
		else
			cdao.insert(curso);
	}
	/**
	 * Metodo que permite obtener el listado de cursos
	 * @return
	 */
	public List<Curso> getListadoCurso(){
		return cdao.getCursos();
	}
	/**
	 * Metodo que permite eliminar un curso dado el id
	 * @param id
	 * @throws Exception
	 */
	public void eliminar(int id) throws Exception{
		Curso aux=cdao.read(id);
		if (aux==null) 
			throw new Exception("Curso no registrada");
		else
			cdao.remove(id);
	}
	/**
	 * Metodo para actualizar un registro
	 * @param curso
	 * @throws Exception
	 */
	public void actualizar(Curso curso) throws Exception {
		Curso aux=cdao.read(curso.getId());
		if(aux==null)
			throw new Exception("Estudiante no registrado");
		else
			cdao.update(curso);
	}
	
	/**
	 * Metodo para obtener un curso
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public Curso getCur(int id) throws Exception{
		Curso aux=cdao.read(id);
		if(aux==null)
			throw new Exception("Curso no existe");
		else
			return aux;
	}
}
