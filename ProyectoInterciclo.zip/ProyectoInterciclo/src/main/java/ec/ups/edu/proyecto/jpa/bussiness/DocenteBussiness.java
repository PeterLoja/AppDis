package ec.ups.edu.proyecto.jpa.bussiness;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import ec.ups.edu.proyecto.jpa.dao.DocenteDAO;
import ec.ups.edu.proyecto.jpa.model.Docente;

@Stateless
public class DocenteBussiness {

	@Inject
	private DocenteDAO dao;
	/**
	 * Metodo para guardar un registro 
	 * @param docente
	 * @throws Exception
	 */
	public void save(Docente docente) throws Exception {
		Docente aux = dao.read(docente.getId());
		if (aux != null)
			throw new Exception("Docente ya registrado");
		else
			dao.insert(docente);
	}
	
	public List<Docente> getListadoDocentes() {
		return dao.getDocentes();
	}
	/**
	 * Metodo para eliminar un registro
	 * @param id
	 * @throws Exception
	 */
	public void eliminar(int id) throws Exception {
		Docente aux = dao.read(id);
		if (aux == null)
			throw new Exception("Docente no registrado");
		else
			dao.remove(id);
	}
	/**
	 * Metodo para actualizar un registro
	 * @param docente
	 * @throws Exception
	 */
	public void actualizar(Docente docente) throws Exception {
		Docente aux = dao.read(docente.getId());
		if (aux == null)
			throw new Exception("Docente no registrado");
		else
			dao.update(docente);
	}
	
	/**
	 * Metodo que permite validar si la cedula es legal
	 * @param cedula
	 * @return
	 */
	public boolean validarCed(String cedula) {
		boolean cedulaCorrecta = false;

		try {

			if (cedula.length() == 10) // ConstantesApp.LongitudCedula
			{
				int tercerDigito = Integer.parseInt(cedula.substring(2, 3));
				if (tercerDigito < 6) {

					int[] coefValCedula = { 2, 1, 2, 1, 2, 1, 2, 1, 2 };
					int verificador = Integer.parseInt(cedula.substring(9, 10));
					int suma = 0;
					int digito = 0;
					for (int i = 0; i < (cedula.length() - 1); i++) {
						digito = Integer.parseInt(cedula.substring(i, i + 1)) * coefValCedula[i];
						suma += ((digito % 10) + (digito / 10));
					}

					if ((suma % 10 == 0) && (suma % 10 == verificador)) {
						cedulaCorrecta = true;
					} else if ((10 - (suma % 10)) == verificador) {
						cedulaCorrecta = true;
					} else {
						cedulaCorrecta = false;
					}
				} else {
					cedulaCorrecta = false;
				}
			} else {
				cedulaCorrecta = false;
			}
		} catch (NumberFormatException nfe) {
			cedulaCorrecta = false;
		} catch (Exception err) {
			System.out.println("Una excepcion ocurrio en el proceso de validacion");
			cedulaCorrecta = false;
		}

		if (!cedulaCorrecta) {
			System.out.println("La cedula no es valida");
		}
		return cedulaCorrecta;
	}
}
