package ec.ups.edu.proyecto.jpa.bussiness;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import ec.ups.edu.proyecto.jpa.dao.RepresentanteDAO;
import ec.ups.edu.proyecto.jpa.model.Estudiante;
import ec.ups.edu.proyecto.jpa.model.Representante;

@Stateless
public class RepresentanteBussiness {

	@Inject
	private RepresentanteDAO rdao;
	/**
	 * Metodo para guardar un registro 
	 * @param representante
	 * @throws Exception
	 */
	public void save(Representante representante) throws Exception {
		Representante aux = rdao.read(representante.getId());
		if (aux != null)
			throw new Exception("Estudiante ya registrado");
		else
			rdao.insert(representante);
	}
	/**
	 * Metodo para listar los representantes
	 * @return
	 */
	public List<Representante> getListadoRepresentante() {
		return rdao.getRepresentantes();
	}
	/**
	 * Metodo para eliminar un registro
	 * @param id
	 * @throws Exception
	 */
	public void eliminar(int id) throws Exception {
		Representante aux = rdao.read(id);
		if (aux == null)
			throw new Exception("Persona no registrada");
		else
			rdao.remove(id);
	}
	/**
	 * Metodo para actualizar un registro
	 * @param representante
	 * @throws Exception
	 */
	public void actualizar(Representante representante) throws Exception {
		Representante aux = rdao.read(representante.getId());
		if (aux == null)
			throw new Exception("Estudiante no registrado");
		else
			rdao.update(representante);
	}
	
	
	
}
