package ec.ups.edu.proyecto.jpa.dao;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import ec.ups.edu.proyecto.jpa.model.Administrador;
/**
 * Clase que permite hace la persistencia sobre la base
 * @author Pedro
 *
 */
@Stateless
public class AdministradorDAO {

	@Inject
	private EntityManager em;
	/**
	 * Permite verificar si existe el administrador en la base
	 * @param usuario
	 * @param pass
	 * @return
	 */
	public Administrador admi(String usuario, String pass) {
		String jpql = "SELECT a FROM Administrador a WHERE a.usuario=:usuario AND a.pass=:pass";
		Query query = em.createQuery(jpql, Administrador.class);
		query.setParameter("usuario", usuario);
		query.setParameter("pass", pass);
		Administrador admi = (Administrador) query.getSingleResult();
		return admi;
	}
}
