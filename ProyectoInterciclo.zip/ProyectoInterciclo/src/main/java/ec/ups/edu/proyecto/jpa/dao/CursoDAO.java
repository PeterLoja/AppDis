package ec.ups.edu.proyecto.jpa.dao;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import ec.ups.edu.proyecto.jpa.model.Curso;
/**
 * Clase que permite hace la persistencia sobre la base
 * @author Pedro
 *
 */
@Stateless
public class CursoDAO {
	
	@Inject
	private EntityManager em;
	/**
	 * Permite guardar un registro
	 * @param curso
	 */
	public void insert(Curso curso) {
		em.persist(curso);
	}
	/**
	 * Permite actualizar un registro
	 * @param curso
	 */
	public void update(Curso curso) {
		em.merge(curso);
	}
	/**
	 * Permite eliminar un registro
	 * @param id
	 */
	public void remove(int id) {
		em.remove(read(id));
	}
	/**
	 * Permite buscar por el id 
	 * @param id
	 * @return
	 */
	public Curso read(int id) {
		Curso aux=em.find(Curso.class, id);
		return aux;
	}
	/**
	 * Permite listar 
	 * @return
	 */
	public List<Curso> getCursos(){
		String jpql="SELECT c FROM Curso c";
		Query q=em.createQuery(jpql,Curso.class);
		List<Curso> lista=q.getResultList();
		return lista;
	}
}
