package ec.ups.edu.proyecto.jpa.dao;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import ec.ups.edu.proyecto.jpa.model.Docente;
/**
 * Clase que permite hace la persistencia sobre la base
 * @author Pedro
 *
 */
@Stateless
public class DocenteDAO {

	@Inject
	private EntityManager em;
	/**
	 * Permite guardar un registro
	 * @param docente
	 */
	public void insert(Docente docente) {
		em.persist(docente);
	}
	/**
	 * Permite actualizar un registro
	 * @param docente
	 */
	public void update(Docente docente) {
		em.merge(docente);
	}

	/**
	 *  Permite eliminar un registro
	 * @param id
	 */
	public void remove(int id) {
		em.remove(read(id));
	}

	/**
	 * Permite buscar por el id 
	 * @param id
	 * @return
	 */
	public Docente read(int id) {
		Docente aux=em.find(Docente.class, id);
		return aux;
	}
	/**
	 * Permite listar
	 * @return
	 */
	public List<Docente> getDocentes(){
		String jpql="SELECT d FROM Docente d";
		Query q=em.createQuery(jpql,Docente.class);
		List<Docente> lista=q.getResultList();
		return lista;
	}
}
