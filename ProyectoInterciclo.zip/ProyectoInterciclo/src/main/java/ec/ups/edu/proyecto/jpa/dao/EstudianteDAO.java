package ec.ups.edu.proyecto.jpa.dao;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.ws.rs.QueryParam;

import ec.ups.edu.proyecto.jpa.model.Estudiante;
/**
 * Clase que permite hace la persistencia sobre la base
 * @author Pedro
 *
 */
@Stateless
public class EstudianteDAO {
	
	@Inject
	private EntityManager em;
	/**
	 * Permite guardar un registro
	 * @param estudiante
	 */
	public void insert(Estudiante estudiante) {
		em.persist(estudiante);
	}
	/**
	 * Permite actualizar un registro
	 * @param estudiante
	 */
	public void update(Estudiante estudiante) {
		em.merge(estudiante);
	}

	/**
	 *  Permite eliminar un registro
	 * @param id
	 */
	public void remove(int id) {
		em.remove(read(id));
	}

	/**
	 * Permite buscar por el id 
	 * @param id
	 * @return
	 */
	public Estudiante read(int id) {
		Estudiante aux=em.find(Estudiante.class, id);
		return aux;
	}
	/**
	 * Permite listar
	 * @return
	 */
	public List<Estudiante> getEstudiantes(){
		String jpql="SELECT e FROM Estudiante e";
		Query q=em.createQuery(jpql,Estudiante.class);
		List<Estudiante> lista=q.getResultList();
		return lista;
	}
	
	/**
	 * Permite iniciar sesion con las credenciales correctas
	 * @param usuario
	 * @param pass
	 * @return
	 */
	public Estudiante listaadmiBD(String usuario, String pass){
		String jpql = "SELECT e FROM Estudiante e WHERE e.correo=:correo AND e.contrasena=:pass";
		Query query = em.createQuery(jpql, Estudiante.class);
		query.setParameter("correo", usuario);
		query.setParameter("pass", pass);
		Estudiante est = (Estudiante) query.getSingleResult();		
		return est;
	}
	
	public Estudiante bEstudiante(int id) {
		Estudiante estudiante=em.find(Estudiante.class,id);
		return estudiante;
	}
}