package ec.ups.edu.proyecto.jpa.dao;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import ec.ups.edu.proyecto.jpa.model.Representante;
/**
 * Clase que permite hace la persistencia sobre la base
 * @author Pedro
 *
 */
@Stateless
public class RepresentanteDAO {
	
	@Inject
	private EntityManager em;
	/**
	 * Permite guardar un registro
	 * @param representante
	 */
	public void insert(Representante representante) {
		em.persist(representante);
	}
	/**
	 * Permite actualizar un registro
	 * @param representante
	 */
	public void update(Representante representante) {
		em.merge(representante);
	}

	/**
	 * Permite eliminar un registro
	 * @param id
	 */
	public void remove(int id) {
		em.remove(read(id));
	}

	/**
	 * Permite buscar por el id 
	 * @param id
	 * @return
	 */
	public Representante read(int id) {
		Representante aux=em.find(Representante.class, id);
		return aux;
	}
	/**
	 * Permite listar
	 * @return
	 */
	public List<Representante> getRepresentantes(){
		String jpql="SELECT r FROM Representante r";
		Query q=em.createQuery(jpql,Representante.class);
		List<Representante> lista=q.getResultList();
		return lista;
	}

}
