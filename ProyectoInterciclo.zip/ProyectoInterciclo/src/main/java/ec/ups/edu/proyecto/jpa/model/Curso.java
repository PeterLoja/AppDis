package ec.ups.edu.proyecto.jpa.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
/*
 * Clase sobre la cual se aplicara persistencia
 */
@Entity
@Table(name="tbl_Curso")
public class Curso {
	/**
	 * Atributos de la clase curso
	 * con los metodos get y set
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="cur_id")
	private int id;
	@NotNull
	@NotEmpty
	private String paralelo;
	@NotNull
	@NotEmpty
	private String aula;
	@NotNull
	@NotEmpty
	private String descripcion;
	
	@OneToMany(cascade = {CascadeType.ALL}, fetch=FetchType.EAGER)
	@JoinColumn(name="cur_id",referencedColumnName="cur_id")
	private List<Horario> horarios;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getParalelo() {
		return paralelo;
	}
	public void setParalelo(String paralelo) {
		this.paralelo = paralelo;
	}
	public String getAula() {
		return aula;
	}
	public void setAula(String aula) {
		this.aula = aula;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	@Override
	public String toString() {
		return "Curso [id=" + id + ", paralelo=" + paralelo + ", aula=" + aula + ", descripcion=" + descripcion + "]";
	}
	
	
	
	public List<Horario> getHorarios() {
		return horarios;
	}
	public void setHorarios(List<Horario> horarios) {
		this.horarios = horarios;
	}
	public void addHorario(Horario horario) {
		if(horarios == null)
			horarios = new ArrayList<>();
		horarios.add(horario);
	}
	
}
