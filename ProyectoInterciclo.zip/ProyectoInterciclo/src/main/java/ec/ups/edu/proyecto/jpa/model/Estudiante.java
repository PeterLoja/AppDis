package ec.ups.edu.proyecto.jpa.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
/*
 * Clase sobre la cual se aplicara persistencia
 */
@Entity
@Table(name="tbl_Estudiantes", uniqueConstraints=@UniqueConstraint(columnNames="correo"))
public class Estudiante {
	/**
	 * Atributos de la clase estudiante
	 * con los metodos get y set
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="est_id")
	private int id;
	
	@NotNull
	@NotEmpty
	@Size(min=1, max=10)
	private String cedula;
	
	@NotNull
	@NotEmpty
	private String nombre;
	@NotNull
	@NotEmpty
	private String apellido;
	
	@Email
	private String correo;
	@NotNull
	@NotEmpty
	private String contrasena;
	
	@OneToMany(cascade = {CascadeType.ALL}, fetch=FetchType.EAGER)
	@JoinColumn(name="est_id",referencedColumnName="est_id")
	private List<Representante> representantes;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCedula() {
		return cedula;
	}
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public String getContrasena() {
		return contrasena;
	}
	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}
	public List<Representante> getRepresentantes() {
		return representantes;
	}
	public void setRepresentantes(List<Representante> representantes) {
		this.representantes = representantes;
	}
	
	@Override
	public String toString() {
		return "Estudiante [id=" + id + ", cedula=" + cedula + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", correo=" + correo + ", contrasena=" + contrasena + ", representantes=" + representantes + "]";
	}
	public void addRepresentante(Representante representante) {
		if(representantes == null)
			representantes= new ArrayList<>();
		representantes.add(representante);
	}
}
