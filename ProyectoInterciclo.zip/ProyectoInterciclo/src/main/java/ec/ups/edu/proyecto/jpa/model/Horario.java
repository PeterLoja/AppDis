package ec.ups.edu.proyecto.jpa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
/*
 * Clase sobre la cual se aplicara persistencia
 */
@Entity
@Table(name="tbl_Horario")
public class Horario {
	/**
	 * Atributos de la clase horario
	 * con los metodos get y set
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="hor_id")
	private int id;
	
	private String HE;
	
	private String HS;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHE() {
		return HE;
	}
	public void setHE(String hE) {
		HE = hE;
	}
	public String getHS() {
		return HS;
	}
	public void setHS(String hS) {
		HS = hS;
	}
	
	@Override
	public String toString() {
		return "Horario [id=" + id + ", HE=" + HE + ", HS=" + HS + "]";
	}
	
}
