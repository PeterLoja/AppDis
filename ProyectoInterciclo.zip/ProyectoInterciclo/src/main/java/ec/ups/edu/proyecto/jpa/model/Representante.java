package ec.ups.edu.proyecto.jpa.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

/*
 * Clase sobre la cual se aplicara persistencia
 */
@Entity
@Table(name="tbl_representante")
public class Representante {
	/**
	 * Atributos de la clase representante
	 * con los metodos get y set
	 */
	@Id
	@GeneratedValue
	@Column(name="rep_id")
	private int id;
	
	@Column(name="rep_nombre")
	@NotNull
	private String nombre;
	
	@Column(name="rep_direccion")
	@NotNull
	private String direccion;
	
	@Column(name="rep_telefono")
	@NotNull
	private String telefono;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Override
	public String toString() {
		return "Representante [id=" + id + ", nombre=" + nombre + ", direccion=" + direccion + ", telefono=" + telefono
				+ "]";
	}

	
}
