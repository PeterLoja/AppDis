package ec.ups.edu.proyecto.jpa.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import ec.ups.edu.proyecto.jpa.bussiness.AdministradorBussiness;
import ec.ups.edu.proyecto.jpa.bussiness.EstudianteBussiness;
import ec.ups.edu.proyecto.jpa.model.Administrador;
import ec.ups.edu.proyecto.jpa.model.Estudiante;
/**
 * Clase en la cual publicamos los metodos que seran expuestos
 * y consumidos por la aplicacion en ionic
 * @author Pedro
 *
 */
@Path("/administrador")
public class AdministradorServiceRest {

	@Inject
	private AdministradorBussiness aBussiness;
	
	@Inject
	private EstudianteBussiness eBussiness;
	
	/**
	 * Metodo para verificar credenciales de administrador
	 * @param usuario
	 * @param pass
	 * @return
	 */
	@GET
	@Path("/login")
	@Produces("application/json")
	public Administrador Iniciar(@QueryParam("usuario")String usuario, @QueryParam("pass")String pass) {
		return aBussiness.Iniciar(usuario, pass);
	}
	/**
	 * Metodo para listar los estudiantes
	 * @return
	 */
	@GET
	@Path("/listar")
	@Produces("application/json")
	public List<Estudiante> getEstudiantes(){
		return eBussiness.getListadoEstudiantes();
	}
	
	/**
	 * Metodo para guardar
	 * @param estudiante
	 * @return
	 */
	@POST
	@Path("/save")
	@Consumes("application/json")
	@Produces("application/json")
	public Response insertEst(Estudiante estudiante) {
		ResponseBuilder builder = null;
		Map<String, String> data = new HashMap<>();
		
		try {
			eBussiness.save(estudiante);
			data.put("code", "1");
			data.put("message", "ok");
			builder = Response.status(Response.Status.OK).entity(data);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			data.put("code", "99");
			data.put("message", e.getMessage());
			builder = Response.status(Response.Status.OK).entity(data);
		}
		return builder.build();
	}
	/**
	 * Metodo para actualizar
	 * @param estudiante
	 * @return
	 */
	@POST
	@Path("/update")
	@Consumes("application/json")
	@Produces("application/json")
	public Response updateEst(Estudiante estudiante) {
		ResponseBuilder builder = null;
		Map<String, String> data = new HashMap<>();
		try {
			eBussiness.actualizar(estudiante);
			data.put("code", "1");
			data.put("message", "ok");
			builder = Response.status(Response.Status.OK).entity(data);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			data.put("code", "99");
			data.put("message", e.getMessage());
			builder = Response.status(Response.Status.OK).entity(data);
		}
		return builder.build();
	}
	/**
	 * Metodo para borrar
	 * @param codigo
	 * @return
	 */
	@POST
	@Path("/delete")
	@Consumes("application/json")
	@Produces("application/json")
	public Response borrarEst(int codigo) {
		ResponseBuilder builder = null;
		Map<String, String> data = new HashMap<>();
		
		try {
			eBussiness.eliminar(codigo);
			data.put("code", "1");
			data.put("message", "ok");
			builder = Response.status(Response.Status.OK).entity(data);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			data.put("code", "99");
			data.put("message", e.getMessage());
			builder = Response.status(Response.Status.OK).entity(data);
		}
		return builder.build();
	}	
	/**
	 * Metodo para buscar
	 * @param id
	 * @return
	 */
	@GET
	@Path("/buscar")
	@Produces("application/json")
	public Estudiante buscar(@QueryParam("id")int id) {
		return eBussiness.buscar(id);
	}
}
