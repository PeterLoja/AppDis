package ec.ups.edu.proyecto.jpa.services;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/srv")
public class EstudianteRESTApplication extends Application {

}
