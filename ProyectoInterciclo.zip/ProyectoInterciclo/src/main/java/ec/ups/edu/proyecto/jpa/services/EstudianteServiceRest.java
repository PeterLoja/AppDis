package ec.ups.edu.proyecto.jpa.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import ec.ups.edu.proyecto.jpa.bussiness.EstudianteBussiness;
import ec.ups.edu.proyecto.jpa.model.Estudiante;
/**
 * Clase en la cual publicamos los metodos que seran expuestos
 * y consumidos por la aplicacion en ionic
 * @author Pedro
 *
 */
@Path("/estudiantes")
public class EstudianteServiceRest {
	
	@Inject
	private EstudianteBussiness eBussiness;
	/**
	 * Metodo para dar verificar credenciales de estudiante
	 * @param correo
	 * @param contrasena
	 * @return
	 */
	@GET
	@Path("/login")
	@Produces("application/json")
	public Estudiante Iniciar(@QueryParam("correo")String correo, @QueryParam("contrasena")String contrasena){
		return eBussiness.Iniciar(correo, contrasena);
	}
	
	
}
