package ec.ups.edu.proyecto.jpa.view;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import ec.ups.edu.proyecto.jpa.bussiness.AdministradorBussiness;
import ec.ups.edu.proyecto.jpa.dao.AdministradorDAO;
import ec.ups.edu.proyecto.jpa.model.Administrador;
import ec.ups.edu.proyecto.jpa.util.SessionUtils;
/**
 * Clase para el manejo de datos ingresados 
 * en la interfaz .xhtml
 * @author Pedro
 *
 */
@ManagedBean
@ViewScoped
public class AdministradorBean {
	
	@Inject
	private AdministradorDAO adao;
	
	@Inject
	private AdministradorBussiness aBussiness;
	
	@Inject
	private FacesContext facesContext;
	
	private Administrador newAdministrador;
	
	private String usuario;
	private String pass;
	
	@PostConstruct
	public void init() {
		newAdministrador=new Administrador();
	}

	public Administrador getNewAdministrador() {
		return newAdministrador;
	}

	public void setNewAdministrador(Administrador newAdministrador) {
		this.newAdministrador = newAdministrador;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}
	
	public String IniciarSesion() {
		try {
			if (usuario != null && pass != null) {
				System.out.println("verificando usuario, pass...");
				newAdministrador = aBussiness.Iniciar(usuario, pass);
				HttpSession session = SessionUtils.getSession();
				session.setAttribute("username", usuario);
				if(newAdministrador != null) {
					System.out.println("Id: "+ newAdministrador.getId());
					return "index?faces-redirect=true";
				} else {
					return "Login?faces-redirect=true";
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("No se puede iniciar sesion");
			//e.printStackTrace();	
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
            facesContext.addMessage(null, m);
		}		
		return "";	
	}
	
	public String logout() {
		HttpSession session = SessionUtils.getSession();
		session.invalidate();
		System.out.println("Entro");
		return "Login?faces-redirect=true";
	}
}
