package ec.ups.edu.proyecto.jpa.view;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import ec.ups.edu.proyecto.jpa.bussiness.CursoBussiness;
import ec.ups.edu.proyecto.jpa.dao.CursoDAO;
import ec.ups.edu.proyecto.jpa.model.Curso;
import ec.ups.edu.proyecto.jpa.model.Horario;
/**
 * Clase para el manejo de datos ingresados 
 * en la interfaz .xhtml
 * @author Pedro
 *
 */
@ManagedBean
@ViewScoped
public class CursoBean {

	@Inject
	private CursoBussiness cBussiness;
	
	@Inject
	private CursoDAO cdao;
	
	@Inject
	private FacesContext facesContext;
	
	private Curso newCurso;
	
	private List<Curso> cursos;
	
	private boolean editing;
	
	private int id;
	
	@PostConstruct
	public void init() {
		newCurso=new Curso();
		newCurso.addHorario(new Horario());
		editing=false;
		cursos=cBussiness.getListadoCurso();
		
	}
	
	public void loadData() {
		System.out.println("load data " + id);
		if (id == 0)
			return;
		try {
			newCurso = cBussiness.getCur(id);
			editing = true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
			facesContext.addMessage(null, m);
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public Curso getNewCurso() {
		return newCurso;
	}

	public void setNewCurso(Curso newCurso) {
		this.newCurso = newCurso;
	}	
	
	public List<Curso> getCursos() {
		return cursos;
	}

	public void setCursos(List<Curso> cursos) {
		this.cursos = cursos;
	}

	public boolean isEditing() {
		return editing;
	}

	public void setEditing(boolean editing) {
		this.editing = editing;
	}
	
	public String guardar() {
		System.out.println("Editando " + editing);
		try {
			if (editing)
				cBussiness.actualizar(newCurso);
			else
				cBussiness.save(newCurso);

			System.out.println("Registro Guardado");
			return "ListCursos?faces-redirect=true";
		} catch (Exception e) {
			System.out.println("Error al guardar");
			e.printStackTrace();
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
			facesContext.addMessage(null, m);
		}
		return null;
	}
	
	public String eliminar(int id) {
		try {
			cBussiness.eliminar(id);
			System.out.println("Registro Eliminado");
			return "ListCursos?faces-redirect=true";
		} catch (Exception e) {
			System.out.println("Error al Eliminar");
			e.printStackTrace();
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
			facesContext.addMessage(null, m);
		}
		return null;
	}
	
	public String editar(Curso cur) {
		System.out.println(cur);
		return "Curso?faces-redirect=true&id=" + cur.getId();
	}
	
	public String addHorario() {
		newCurso.addHorario(new Horario());
		return null;
	}
}
