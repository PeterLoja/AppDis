package ec.ups.edu.proyecto.jpa.view;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import ec.ups.edu.proyecto.jpa.bussiness.DocenteBussiness;
import ec.ups.edu.proyecto.jpa.dao.DocenteDAO;
import ec.ups.edu.proyecto.jpa.model.Docente;
/**
 * Clase para el manejo de datos ingresados 
 * en la interfaz .xhtml
 * @author Pedro
 *
 */
@ManagedBean
public class DocenteBean {

	@Inject
	private DocenteBussiness dBussiness;

	@Inject
	private FacesContext facesContext;

	private Docente newDocente;

	private List<Docente> docentes;

	private boolean editing;

	@PostConstruct
	public void init() {
		newDocente = new Docente();
		editing = false;
		docentes = dBussiness.getListadoDocentes();
	}

	public Docente getNewDocente() {
		return newDocente;
	}

	public void setNewDocente(Docente newDocente) {
		this.newDocente = newDocente;
	}

	public List<Docente> getDocentes() {
		return docentes;
	}

	public void setDocentes(List<Docente> docentes) {
		this.docentes = docentes;
	}

	public boolean isEditing() {
		return editing;
	}

	public void setEditing(boolean editing) {
		this.editing = editing;
	}

	public String guardar() {
		System.out.println("Editando " + editing);
		try {
			String cedula = newDocente.getCedula();
			if (dBussiness.validarCed(cedula) == true) {
				if (editing)
					dBussiness.actualizar(newDocente);
				else
					dBussiness.save(newDocente);
				System.out.println("Registro Guardado");
				return "ListDocentes?faces-redirect=true";
			} else
				return "Error";
		} catch (Exception e) {
			System.out.println("Error al guardar");
			e.printStackTrace();
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
			facesContext.addMessage(null, m);
		}
		return null;
	}
	
	public String eliminar(int id) {
		try {
			dBussiness.eliminar(id);
			;
			System.out.println("Registro Eliminado");
			return "ListDocentes?faces-redirect=true";
		} catch (Exception e) {
			System.out.println("Error al Eliminar");
			e.printStackTrace();
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
			facesContext.addMessage(null, m);
		}
		return null;
	}
	
	public String editar(Docente docente) {
		editing=true;
		newDocente = docente;
		return "Docente";
	}
}
