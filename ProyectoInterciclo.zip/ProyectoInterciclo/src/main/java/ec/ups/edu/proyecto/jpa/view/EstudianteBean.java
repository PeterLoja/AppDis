package ec.ups.edu.proyecto.jpa.view;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import ec.ups.edu.proyecto.jpa.bussiness.EstudianteBussiness;
import ec.ups.edu.proyecto.jpa.dao.EstudianteDAO;
import ec.ups.edu.proyecto.jpa.model.Estudiante;
import ec.ups.edu.proyecto.jpa.model.Representante;
import ec.ups.edu.proyecto.jpa.util.SessionUtils;
/**
 * Clase para el manejo de datos ingresados 
 * en la interfaz .xhtml
 * @author Pedro
 *
 */
@ManagedBean
@ViewScoped
public class EstudianteBean {

	@Inject
	private EstudianteBussiness eBussiness;

	@Inject
	private EstudianteDAO edao;

	@Inject
	private FacesContext facesContext;

	private Estudiante newEstudiante;

	private List<Estudiante> estudiantes;

	private boolean editing;

	private int id;
	
	private String correo;
	private String contrasena;
	
	

	@PostConstruct
	public void init() {
		newEstudiante = new Estudiante();
		newEstudiante.addRepresentante(new Representante());
		editing = false;
		estudiantes = eBussiness.getListadoEstudiantes();
	}

	public void loadData() {
		System.out.println("load data " + id);
		if (id == 0)
			return;
		try {
			newEstudiante = eBussiness.getEst(id);
			editing = true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
			facesContext.addMessage(null, m);
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Estudiante getNewEstudiante() {
		return newEstudiante;
	}

	public void setNewEstudiante(Estudiante newEstudiante) {
		this.newEstudiante = newEstudiante;
	}

	public List<Estudiante> getEstudiantes() {
		return estudiantes;
	}

	public void setEstudiantes(List<Estudiante> estudiantes) {
		this.estudiantes = estudiantes;
	}

	public boolean isEditing() {
		return editing;
	}

	public void setEditing(boolean editing) {
		this.editing = editing;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getContrasena() {
		return contrasena;
	}

	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}

	public String guardar() {
		System.out.println("Editando " + editing);
		try {
			String cedula = newEstudiante.getCedula();
			if (eBussiness.validarCed(cedula) == true) {
				if (editing)
					eBussiness.actualizar(newEstudiante);
				else
					eBussiness.save(newEstudiante);
				System.out.println("Registro Guardado");
				return "ListEstudiantes?faces-redirect=true";

			} else
				return "Error";
		} catch (Exception e) {
			System.out.println("Error al guardar");
			e.printStackTrace();
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
			facesContext.addMessage(null, m);
		}
		return null;
	}

	public String eliminar(int id) {
		try {
			eBussiness.eliminar(id);
			System.out.println("Registro Eliminado");
			return "ListEstudiantes?faces-redirect=true";
		} catch (Exception e) {
			System.out.println("Error al Eliminar");
			e.printStackTrace();
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
			facesContext.addMessage(null, m);
		}
		return null;
	}

	public String editar(Estudiante est) {
		// editing = true;
		System.out.println(est);
		// newPersona = persona;
		return "EstudianteF?faces-redirect=true&id=" + est.getId();
	}

	public String addRepresentante() {
		newEstudiante.addRepresentante(new Representante());
		return null;
	}
	
	public String inicioSesion() {		
		try {
			if (correo != null && contrasena != null) {
				System.out.println("verificando email, clave...");
				HttpSession session = SessionUtils.getSession();
				session.setAttribute("username", correo);
				newEstudiante = eBussiness.Iniciar(correo, contrasena);
				if(newEstudiante != null) {
					System.out.println("Cedula: "+ newEstudiante.getCedula());
					return "indexE?faces-redirect=true";
				} else {
					return "Login?faces-redirect=true";
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("No se puede iniciar sesion");
			//e.printStackTrace();	
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
            facesContext.addMessage(null, m);
		}		
		return "";
		
	}
	public String logout(){
		HttpSession session = SessionUtils.getSession();
		session.invalidate();
		return "Login?faces-redirect=true";
	}
}
