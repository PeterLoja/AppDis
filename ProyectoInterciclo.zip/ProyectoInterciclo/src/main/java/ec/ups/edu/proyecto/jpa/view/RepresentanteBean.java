package ec.ups.edu.proyecto.jpa.view;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import ec.ups.edu.proyecto.jpa.bussiness.RepresentanteBussiness;
import ec.ups.edu.proyecto.jpa.model.Representante;
/**
 * Clase para el manejo de datos ingresados 
 * en la interfaz .xhtml
 * @author Pedro
 *
 */
@ManagedBean
public class RepresentanteBean {

	@Inject
	private RepresentanteBussiness rBussiness;

	@Inject
	private FacesContext facesContext;

	private Representante newRepresentante;

	private List<Representante> representantes;

	private boolean editing;

	@PostConstruct
	public void init() {
		newRepresentante = new Representante();
		editing = false;
		representantes = rBussiness.getListadoRepresentante();
	}

	public Representante getNewRepresentante() {
		return newRepresentante;
	}

	public void setNewRepresentante(Representante newRepresentante) {
		this.newRepresentante = newRepresentante;
	}

	public List<Representante> getRepresentantes() {
		return representantes;
	}

	public void setRepresentantes(List<Representante> representantes) {
		this.representantes = representantes;
	}

	public boolean isEditing() {
		return editing;
	}

	public void setEditing(boolean editing) {
		this.editing = editing;
	}

	public String guardar() {
		System.out.println("Editando " + editing);
		try {
			if (editing)
				rBussiness.actualizar(newRepresentante);
			else
				rBussiness.save(newRepresentante);
			System.out.println("Registro Guardado");
			return "ListRepresentantes?faces-redirect=true";
		} catch (Exception e) {
			System.out.println("Error al guardar");
			e.printStackTrace();
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
			facesContext.addMessage(null, m);
		}
		return null;
	}
	
	public String eliminar(int id) {
		try {
			rBussiness.eliminar(id);
			;
			System.out.println("Registro Eliminado");
			return "ListRepresentantes?faces-redirect=true";
		} catch (Exception e) {
			System.out.println("Error al Eliminar");
			e.printStackTrace();
			FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "Error");
			facesContext.addMessage(null, m);
		}
		return null;
	}
	
	public String editar(Representante representante) {
		editing=true;
		newRepresentante = representante;
		return "Docente";
	}
	
	
}
